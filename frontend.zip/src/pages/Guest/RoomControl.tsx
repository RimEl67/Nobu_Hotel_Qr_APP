import React, { useState } from 'react';
import { 
  Thermometer, 
  Lightbulb, 
  Tv, 
  Volume2, 
  Wifi, 
  Shield,
  Power,
  Sun,
  Moon,
  Wind
} from 'lucide-react';
import Card from '../../components/UI/Card';
import Button from '../../components/UI/Button';
import BackButton from '../../components/UI/BackButton';
import Navigation from '../../components/Layout/Navigation';
import { useAuth } from '../../contexts/AuthContext';

const RoomControl: React.FC = () => {
  const { user } = useAuth();
  const [temperature, setTemperature] = useState(22);
  const [lighting, setLighting] = useState(75);
  const [tvOn, setTvOn] = useState(false);
  const [volume, setVolume] = useState(30);
  const [curtainsOpen, setCurtainsOpen] = useState(true);
  const [acOn, setAcOn] = useState(true);

  const controlSections = [
    {
      title: 'Température',
      icon: <Thermometer className="text-blue-600" size={24} />,
      content: (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-2xl font-bold text-blue-600">{temperature}°C</span>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => setTemperature(Math.max(16, temperature - 1))}
              >
                -
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setTemperature(Math.min(30, temperature + 1))}
              >
                +
              </Button>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Climatisation</span>
            <button
              onClick={() => setAcOn(!acOn)}
              className={`w-12 h-6 rounded-full transition-colors ${
                acOn ? 'bg-blue-500' : 'bg-gray-300'
              }`}
            >
              <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                acOn ? 'translate-x-6' : 'translate-x-1'
              }`} />
            </button>
          </div>
        </div>
      )
    },
    {
      title: 'Éclairage',
      icon: <Lightbulb className="text-yellow-600" size={24} />,
      content: (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Intensité</span>
            <span className="font-medium">{lighting}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="100"
            value={lighting}
            onChange={(e) => setLighting(Number(e.target.value))}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
          />
          <div className="grid grid-cols-3 gap-2">
            <Button size="sm" variant="outline" onClick={() => setLighting(25)}>
              Tamisé
            </Button>
            <Button size="sm" variant="outline" onClick={() => setLighting(75)}>
              Normal
            </Button>
            <Button size="sm" variant="outline" onClick={() => setLighting(100)}>
              Max
            </Button>
          </div>
        </div>
      )
    },
    {
      title: 'Télévision',
      icon: <Tv className="text-purple-600" size={24} />,
      content: (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">État</span>
            <button
              onClick={() => setTvOn(!tvOn)}
              className={`flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                tvOn 
                  ? 'bg-green-100 text-green-700' 
                  : 'bg-gray-100 text-gray-600'
              }`}
            >
              <Power size={14} />
              {tvOn ? 'Allumée' : 'Éteinte'}
            </button>
          </div>
          {tvOn && (
            <>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Volume</span>
                <span className="font-medium">{volume}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={volume}
                onChange={(e) => setVolume(Number(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
              />
            </>
          )}
        </div>
      )
    },
    {
      title: 'Rideaux',
      icon: curtainsOpen ? <Sun className="text-orange-600" size={24} /> : <Moon className="text-indigo-600" size={24} />,
      content: (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Position</span>
            <span className="font-medium">{curtainsOpen ? 'Ouverts' : 'Fermés'}</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Button
              size="sm"
              variant={curtainsOpen ? "primary" : "outline"}
              onClick={() => setCurtainsOpen(true)}
            >
              <Sun size={16} className="mr-2" />
              Ouvrir
            </Button>
            <Button
              size="sm"
              variant={!curtainsOpen ? "primary" : "outline"}
              onClick={() => setCurtainsOpen(false)}
            >
              <Moon size={16} className="mr-2" />
              Fermer
            </Button>
          </div>
        </div>
      )
    }
  ];

  const quickActions = [
    {
      name: 'Mode Nuit',
      description: 'Éclairage tamisé, rideaux fermés',
      icon: <Moon className="text-indigo-600" size={20} />,
      action: () => {
        setLighting(25);
        setCurtainsOpen(false);
        setTvOn(false);
      }
    },
    {
      name: 'Mode Jour',
      description: 'Éclairage normal, rideaux ouverts',
      icon: <Sun className="text-orange-600" size={20} />,
      action: () => {
        setLighting(75);
        setCurtainsOpen(true);
      }
    },
    {
      name: 'Économie d\'énergie',
      description: 'Optimise la consommation',
      icon: <Wind className="text-green-600" size={20} />,
      action: () => {
        setTemperature(24);
        setLighting(50);
        setTvOn(false);
        setAcOn(false);
      }
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-blue-50 pb-20 lg:pb-0">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <BackButton to="/dashboard" />
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Contrôle de Chambre</h1>
              <p className="text-gray-600">Chambre {user?.roomNumber} • Nobu Hotel</p>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <Card className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Actions Rapides</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {quickActions.map((action, index) => (
              <button
                key={index}
                onClick={action.action}
                className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors text-left"
              >
                {action.icon}
                <div>
                  <div className="font-medium text-gray-900">{action.name}</div>
                  <div className="text-sm text-gray-600">{action.description}</div>
                </div>
              </button>
            ))}
          </div>
        </Card>

        {/* Control Sections */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          {controlSections.map((section, index) => (
            <Card key={index}>
              <div className="flex items-center gap-3 mb-4">
                {section.icon}
                <h3 className="text-lg font-semibold text-gray-900">{section.title}</h3>
              </div>
              {section.content}
            </Card>
          ))}
        </div>

        {/* Room Status */}
        <Card>
          <h2 className="text-lg font-semibold text-gray-900 mb-4">État de la Chambre</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
              <Wifi className="text-blue-600" size={20} />
              <div>
                <div className="font-medium text-gray-900">WiFi</div>
                <div className="text-sm text-green-600">Connecté</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
              <Shield className="text-green-600" size={20} />
              <div>
                <div className="font-medium text-gray-900">Sécurité</div>
                <div className="text-sm text-green-600">Activée</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
              <Volume2 className="text-orange-600" size={20} />
              <div>
                <div className="font-medium text-gray-900">Audio</div>
                <div className="text-sm text-gray-600">{volume}%</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
              <Thermometer className="text-purple-600" size={20} />
              <div>
                <div className="font-medium text-gray-900">Confort</div>
                <div className="text-sm text-green-600">Optimal</div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      <Navigation />
    </div>
  );
};

export default RoomControl;