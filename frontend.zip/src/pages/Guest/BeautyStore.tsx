import React, { useState } from 'react';
import { ShoppingCart, Star, Sparkles, Heart, Leaf, Droplets, Plus, Minus } from 'lucide-react';
import Card from '../../components/UI/Card';
import Button from '../../components/UI/Button';
import BackButton from '../../components/UI/BackButton';
import Modal from '../../components/UI/Modal';
import Navigation from '../../components/Layout/Navigation';
import toast from 'react-hot-toast';

interface BeautyProduct {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'essential-oils' | 'creams' | 'serums' | 'masks';
  image: string;
  rating: number;
  benefits: string[];
  ingredients: string[];
  size: string;
  inStock: boolean;
}

interface CartItem {
  product: BeautyProduct;
  quantity: number;
}

const BeautyStore: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedProduct, setSelectedProduct] = useState<BeautyProduct | null>(null);
  const [showProductModal, setShowProductModal] = useState(false);
  const [showCartModal, setShowCartModal] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);

  const categories = [
    { id: 'all', name: 'All Products', icon: Sparkles },
    { id: 'essential-oils', name: 'Essential Oils', icon: Droplets },
    { id: 'creams', name: 'Luxury Creams', icon: Heart },
    { id: 'serums', name: 'Face Serums', icon: Leaf },
    { id: 'masks', name: 'Face Masks', icon: Sparkles },
  ];

  const products: BeautyProduct[] = [
    // Essential Oils
    {
      id: '1',
      name: 'Moroccan Argan Oil',
      description: 'Pure organic argan oil from the Atlas Mountains, perfect for hair and skin nourishment.',
      price: 85,
      category: 'essential-oils',
      image: 'https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg',
      rating: 4.9,
      benefits: ['Deep moisturizing', 'Anti-aging properties', 'Hair strengthening', 'Skin repair'],
      ingredients: ['100% Pure Argan Oil', 'Vitamin E', 'Essential Fatty Acids'],
      size: '50ml',
      inStock: true,
    },
    {
      id: '2',
      name: 'Lavender Essential Oil',
      description: 'Calming lavender oil from French Provence, ideal for relaxation and aromatherapy.',
      price: 65,
      category: 'essential-oils',
      image: 'https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg',
      rating: 4.8,
      benefits: ['Stress relief', 'Better sleep', 'Skin soothing', 'Aromatherapy'],
      ingredients: ['Pure Lavender Oil', 'Natural Linalool', 'Lavandyl Acetate'],
      size: '30ml',
      inStock: true,
    },
    {
      id: '3',
      name: 'Rose Hip Seed Oil',
      description: 'Premium rose hip oil rich in vitamins and antioxidants for radiant skin.',
      price: 95,
      category: 'essential-oils',
      image: 'https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg',
      rating: 4.7,
      benefits: ['Skin regeneration', 'Scar healing', 'Anti-aging', 'Hydration'],
      ingredients: ['Rose Hip Seed Oil', 'Vitamin C', 'Omega Fatty Acids'],
      size: '30ml',
      inStock: true,
    },
    {
      id: '4',
      name: 'Eucalyptus Oil',
      description: 'Refreshing eucalyptus oil for respiratory wellness and muscle relief.',
      price: 55,
      category: 'essential-oils',
      image: 'https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg',
      rating: 4.6,
      benefits: ['Respiratory support', 'Muscle relief', 'Mental clarity', 'Antimicrobial'],
      ingredients: ['Pure Eucalyptus Oil', 'Eucalyptol', 'Natural Terpenes'],
      size: '30ml',
      inStock: true,
    },

    // Luxury Creams
    {
      id: '5',
      name: 'Gold Infused Night Cream',
      description: 'Luxurious anti-aging night cream infused with 24k gold particles.',
      price: 180,
      category: 'creams',
      image: 'https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg',
      rating: 4.9,
      benefits: ['Anti-aging', 'Skin firming', 'Deep hydration', 'Luxury experience'],
      ingredients: ['24k Gold', 'Hyaluronic Acid', 'Peptides', 'Shea Butter'],
      size: '50ml',
      inStock: true,
    },
    {
      id: '6',
      name: 'Moroccan Clay Face Cream',
      description: 'Nourishing face cream with authentic Moroccan clay and argan oil.',
      price: 120,
      category: 'creams',
      image: 'https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg',
      rating: 4.8,
      benefits: ['Pore cleansing', 'Oil control', 'Skin purification', 'Natural glow'],
      ingredients: ['Moroccan Clay', 'Argan Oil', 'Aloe Vera', 'Rose Water'],
      size: '75ml',
      inStock: true,
    },
    {
      id: '7',
      name: 'Intensive Hand Cream',
      description: 'Rich hand cream with shea butter and vitamin E for soft, smooth hands.',
      price: 45,
      category: 'creams',
      image: 'https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg',
      rating: 4.7,
      benefits: ['Deep moisturizing', 'Hand protection', 'Quick absorption', 'Long-lasting'],
      ingredients: ['Shea Butter', 'Vitamin E', 'Glycerin', 'Coconut Oil'],
      size: '100ml',
      inStock: true,
    },
    {
      id: '8',
      name: 'Body Butter Cream',
      description: 'Ultra-rich body cream with cocoa butter and natural oils.',
      price: 75,
      category: 'creams',
      image: 'https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg',
      rating: 4.8,
      benefits: ['Intense hydration', 'Skin softening', 'Long-lasting moisture', 'Natural fragrance'],
      ingredients: ['Cocoa Butter', 'Coconut Oil', 'Vitamin E', 'Natural Fragrance'],
      size: '200ml',
      inStock: true,
    },

    // Face Serums
    {
      id: '9',
      name: 'Vitamin C Brightening Serum',
      description: 'Powerful vitamin C serum for brighter, more radiant skin.',
      price: 110,
      category: 'serums',
      image: 'https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg',
      rating: 4.9,
      benefits: ['Skin brightening', 'Dark spot reduction', 'Antioxidant protection', 'Collagen boost'],
      ingredients: ['Vitamin C', 'Hyaluronic Acid', 'Niacinamide', 'Vitamin E'],
      size: '30ml',
      inStock: true,
    },
    {
      id: '10',
      name: 'Hyaluronic Acid Serum',
      description: 'Intensive hydrating serum with multiple types of hyaluronic acid.',
      price: 95,
      category: 'serums',
      image: 'https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg',
      rating: 4.8,
      benefits: ['Deep hydration', 'Plumping effect', 'Fine line reduction', 'Skin barrier repair'],
      ingredients: ['Hyaluronic Acid', 'Sodium Hyaluronate', 'Glycerin', 'Aloe Vera'],
      size: '30ml',
      inStock: true,
    },
    {
      id: '11',
      name: 'Retinol Anti-Aging Serum',
      description: 'Advanced retinol serum for mature skin and anti-aging benefits.',
      price: 135,
      category: 'serums',
      image: 'https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg',
      rating: 4.7,
      benefits: ['Anti-aging', 'Wrinkle reduction', 'Skin renewal', 'Texture improvement'],
      ingredients: ['Retinol', 'Vitamin E', 'Squalane', 'Peptides'],
      size: '30ml',
      inStock: true,
    },

    // Face Masks
    {
      id: '12',
      name: 'Dead Sea Mud Mask',
      description: 'Purifying mud mask with minerals from the Dead Sea.',
      price: 65,
      category: 'masks',
      image: 'https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg',
      rating: 4.8,
      benefits: ['Deep cleansing', 'Pore tightening', 'Oil control', 'Mineral nourishment'],
      ingredients: ['Dead Sea Mud', 'Kaolin Clay', 'Aloe Vera', 'Tea Tree Oil'],
      size: '100ml',
      inStock: true,
    },
    {
      id: '13',
      name: 'Gold Collagen Face Mask',
      description: 'Luxury sheet mask infused with gold and collagen for instant glow.',
      price: 25,
      category: 'masks',
      image: 'https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg',
      rating: 4.9,
      benefits: ['Instant glow', 'Skin firming', 'Hydration boost', 'Luxury treatment'],
      ingredients: ['24k Gold', 'Marine Collagen', 'Hyaluronic Acid', 'Vitamin E'],
      size: '1 sheet',
      inStock: true,
    },
    {
      id: '14',
      name: 'Charcoal Detox Mask',
      description: 'Deep cleansing charcoal mask for oily and acne-prone skin.',
      price: 55,
      category: 'masks',
      image: 'https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg',
      rating: 4.6,
      benefits: ['Deep detox', 'Blackhead removal', 'Oil control', 'Pore cleansing'],
      ingredients: ['Activated Charcoal', 'Bentonite Clay', 'Tea Tree Oil', 'Salicylic Acid'],
      size: '75ml',
      inStock: true,
    },
  ];

  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  const addToCart = (product: BeautyProduct) => {
    setCart(prev => {
      const existingItem = prev.find(item => item.product.id === product.id);
      if (existingItem) {
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    toast.success(`${product.name} added to cart!`);
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      setCart(prev => prev.filter(item => item.product.id !== productId));
    } else {
      setCart(prev =>
        prev.map(item =>
          item.product.id === productId ? { ...item, quantity } : item
        )
      );
    }
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  };

  const getTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  };

  const handleViewProduct = (product: BeautyProduct) => {
    setSelectedProduct(product);
    setShowProductModal(true);
  };

  const handleOrder = () => {
    if (cart.length === 0) {
      toast.error('Your cart is empty');
      return;
    }
    toast.success('Order placed successfully! Items will be delivered to your room.');
    setCart([]);
    setShowCartModal(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-indigo-50 pb-20 lg:pb-0">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <BackButton to="/dashboard" />
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-purple-600 rounded-xl flex items-center justify-center">
                  <Sparkles className="text-white" size={24} />
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-gray-900">Nobu Beauty Store</h1>
                  <p className="text-purple-600 font-medium">Luxury Skincare & Wellness</p>
                </div>
              </div>
              <p className="text-gray-600">Discover our exclusive collection of premium beauty products</p>
            </div>
          </div>
          <Button
            onClick={() => setShowCartModal(true)}
            variant="primary"
            className="relative bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
          >
            <ShoppingCart size={20} />
            {getTotalItems() > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {getTotalItems()}
              </span>
            )}
          </Button>
        </div>

        {/* Categories */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`flex items-center gap-2 px-6 py-3 rounded-xl whitespace-nowrap transition-all font-medium ${
                  selectedCategory === category.id
                    ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-lg'
                    : 'bg-white text-gray-600 hover:bg-pink-50 border border-gray-200'
                }`}
              >
                <Icon size={18} />
                {category.name}
              </button>
            );
          })}
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <Card key={product.id} padding={false} className="overflow-hidden hover:shadow-xl transition-all duration-300 group">
              <div className="relative">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm rounded-xl px-3 py-2 flex items-center gap-1 shadow-lg">
                  <Star className="text-yellow-500 fill-current" size={14} />
                  <span className="text-sm font-bold">{product.rating}</span>
                </div>
                <div className="absolute bottom-4 left-4 bg-gradient-to-r from-pink-500 to-purple-600 text-white px-4 py-2 rounded-full font-bold shadow-lg">
                  ${product.price}
                </div>
              </div>
              
              <div className="p-6">
                <div className="mb-4">
                  <h3 className="font-bold text-lg text-gray-900 mb-2 group-hover:text-purple-600 transition-colors">
                    {product.name}
                  </h3>
                  <p className="text-gray-600 text-sm leading-relaxed mb-3 line-clamp-2">
                    {product.description}
                  </p>
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full">
                      {product.size}
                    </span>
                    {product.inStock ? (
                      <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
                        In Stock
                      </span>
                    ) : (
                      <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full">
                        Out of Stock
                      </span>
                    )}
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button
                    onClick={() => handleViewProduct(product)}
                    variant="outline"
                    size="sm"
                    className="flex-1"
                  >
                    View Details
                  </Button>
                  <Button
                    onClick={() => addToCart(product)}
                    variant="primary"
                    size="sm"
                    className="flex-1 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                    disabled={!product.inStock}
                  >
                    <Plus size={16} className="mr-1" />
                    Add to Cart
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Product Details Modal */}
        <Modal
          isOpen={showProductModal}
          onClose={() => setShowProductModal(false)}
          title="Product Details"
          maxWidth="max-w-2xl"
        >
          {selectedProduct && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <img
                  src={selectedProduct.image}
                  alt={selectedProduct.name}
                  className="w-full h-64 object-cover rounded-lg"
                />
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{selectedProduct.name}</h3>
                  <div className="flex items-center gap-2 mb-4">
                    <div className="flex items-center gap-1">
                      <Star className="text-yellow-500 fill-current" size={16} />
                      <span className="font-medium">{selectedProduct.rating}</span>
                    </div>
                    <span className="text-gray-400">•</span>
                    <span className="text-sm text-gray-600">{selectedProduct.size}</span>
                  </div>
                  <p className="text-gray-600 mb-4">{selectedProduct.description}</p>
                  <div className="text-3xl font-bold text-purple-600 mb-4">${selectedProduct.price}</div>
                  <Button
                    onClick={() => {
                      addToCart(selectedProduct);
                      setShowProductModal(false);
                    }}
                    variant="primary"
                    size="lg"
                    className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                    disabled={!selectedProduct.inStock}
                  >
                    <Plus size={20} className="mr-2" />
                    Add to Cart
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Key Benefits</h4>
                  <ul className="space-y-2">
                    {selectedProduct.benefits.map((benefit, index) => (
                      <li key={index} className="flex items-center gap-2 text-sm text-gray-600">
                        <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                        {benefit}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Key Ingredients</h4>
                  <ul className="space-y-2">
                    {selectedProduct.ingredients.map((ingredient, index) => (
                      <li key={index} className="flex items-center gap-2 text-sm text-gray-600">
                        <Leaf className="text-green-500" size={14} />
                        {ingredient}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}
        </Modal>

        {/* Cart Modal */}
        <Modal
          isOpen={showCartModal}
          onClose={() => setShowCartModal(false)}
          title="Your Beauty Cart"
          maxWidth="max-w-lg"
        >
          {cart.length === 0 ? (
            <div className="text-center py-8">
              <ShoppingCart className="mx-auto text-gray-400 mb-4" size={48} />
              <p className="text-gray-600">Your cart is empty</p>
              <p className="text-sm text-gray-500 mt-2">Add some beauty products to get started</p>
            </div>
          ) : (
            <div>
              <div className="bg-gradient-to-r from-pink-50 to-purple-50 p-4 rounded-lg mb-6 border border-pink-200">
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="text-purple-600" size={20} />
                  <span className="font-semibold text-purple-900">Nobu Beauty Store</span>
                </div>
                <p className="text-sm text-purple-700">
                  Room delivery • Estimated time: 30-45 min
                </p>
              </div>
              
              <div className="space-y-4 mb-6">
                {cart.map((item) => (
                  <div key={item.product.id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl border border-gray-200">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-16 h-16 rounded-xl object-cover"
                    />
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">{item.product.name}</h4>
                      <p className="text-purple-600 font-semibold">${item.product.price}</p>
                      <p className="text-xs text-gray-500">{item.product.size}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                        className="w-8 h-8 rounded-full bg-white border border-gray-300 flex items-center justify-center hover:bg-gray-50 transition-colors"
                      >
                        <Minus size={16} />
                      </button>
                      <span className="w-8 text-center font-bold">{item.quantity}</span>
                      <button
                        onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                        className="w-8 h-8 rounded-full bg-white border border-gray-300 flex items-center justify-center hover:bg-gray-50 transition-colors"
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="border-t pt-4 mb-6">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Subtotal:</span>
                  <span className="font-semibold">${getTotalPrice()}</span>
                </div>
                <div className="flex justify-between items-center mt-2">
                  <span className="text-gray-600">Room delivery:</span>
                  <span className="font-semibold">Free</span>
                </div>
                <div className="flex justify-between items-center text-xl font-bold mt-4 pt-4 border-t">
                  <span>Total:</span>
                  <span className="text-purple-600">${getTotalPrice()}</span>
                </div>
              </div>

              <Button
                onClick={handleOrder}
                variant="primary"
                size="lg"
                className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
              >
                <ShoppingCart size={20} className="mr-2" />
                Place Order
              </Button>
              
              <p className="text-xs text-gray-500 text-center mt-3">
                Products will be delivered to your room within 30-45 minutes
              </p>
            </div>
          )}
        </Modal>
      </div>

      <Navigation />
    </div>
  );
};

export default BeautyStore;