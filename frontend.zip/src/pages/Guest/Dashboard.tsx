import React, { useState, useEffect } from 'react';
import { 
  Utensils, 
  Bell, 
  Calendar, 
  MessageCircle, 
  MapPin, 
  Wifi,
  Clock,
  Package,
  Gift,
  Star,
  Sparkles
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useCart } from '../../contexts/CartContext';
import { apiService } from '../../services/api';
import { MenuItem, ServiceItem, ActivityItem } from '../../types';
import Card from '../../components/UI/Card';
import Slider from '../../components/UI/Slider';
import Button from '../../components/UI/Button';
import Navigation from '../../components/Layout/Navigation';
import toast from 'react-hot-toast';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const { getTotalItems } = useCart();
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [services, setServices] = useState<ServiceItem[]>([]);
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [menuData, servicesData, activitiesData] = await Promise.all([
        apiService.getMenu(),
        apiService.getServices(),
        apiService.getActivities()
      ]);
      setMenuItems(menuData.slice(0, 3));
      setServices(servicesData.slice(0, 3));
      setActivities(activitiesData.slice(0, 3));
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Navigation (statique)
  const navigationServices = [
    {
      title: 'Restaurant',
      description: 'Culinary Excellence',
      icon: Utensils,
      color: 'orange',
      to: '/dashboard/restaurant',
    },
    {
      title: 'Services',
      description: 'Concierge & More',
      icon: Bell,
      color: 'green',
      to: '/dashboard/services',
    },
    {
      title: 'Activities',
      description: 'Spa & Experiences',
      icon: Calendar,
      color: 'purple',
      to: '/dashboard/activities',
    },
    {
      title: 'Chat',
      description: '24/7 Assistance',
      icon: MessageCircle,
      color: 'blue',
      to: '/dashboard/chat',
    },
    {
      title: 'Hotel Map',
      description: 'Navigate in Style',
      icon: MapPin,
      color: 'red',
      to: '/dashboard/hotel-map',
    },
    {
      title: 'Room Control',
      description: 'Smart Amenities',
      icon: Wifi,
      color: 'indigo',
      to: '/dashboard/room-control',
    },
  ];

  const stats = [
    { label: 'Active Orders', value: '0', color: 'blue' },
    { label: 'Service Requests', value: '0', color: 'green' },
    { label: 'Cart Items', value: getTotalItems().toString(), color: 'purple' },
  ];

  // Promo slider
  const sliderData = [
    {
      id: '1',
      title: 'Offre Spéciale Spa',
      subtitle: 'Détente & Bien-être',
      description: "Profitez de 30% de réduction sur tous nos soins spa jusqu'au 31 mars. Réservez dès maintenant votre moment de détente.",
      image: 'https://images.pexels.com/photos/3757942/pexels-photo-3757942.jpeg',
      buttonText: 'Réserver maintenant',
      buttonAction: () => toast.success('Redirection vers les réservations spa...'),
      gradient: 'bg-gradient-to-r from-green-900/70 via-green-700/50 to-transparent'
    },
    {
      id: '2',
      title: 'Happy Hour Restaurant',
      subtitle: 'Cuisine Fusion Japonaise',
      description: 'Découvrez notre menu signature avec 25% de réduction de 17h à 19h tous les jours. Une expérience culinaire unique.',
      image: 'https://images.pexels.com/photos/3026808/pexels-photo-3026808.jpeg',
      buttonText: 'Voir le menu',
      buttonAction: () => toast.success('Redirection vers le restaurant...'),
      gradient: 'bg-gradient-to-r from-orange-900/70 via-orange-700/50 to-transparent'
    },
    {
      id: '3',
      title: 'Package Romance',
      subtitle: 'Séjour Romantique',
      description: "Champagne, pétales de rose, dîner aux chandelles et massage en couple. L'expérience parfaite pour les amoureux.",
      image: 'https://images.pexels.com/photos/338504/pexels-photo-338504.jpeg',
      buttonText: "Découvrir l'offre",
      buttonAction: () => toast.success('Contactez la réception pour plus d\'informations'),
      gradient: 'bg-gradient-to-r from-pink-900/70 via-pink-700/50 to-transparent'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-blue-50 pb-20 lg:pb-0">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-orange-500 rounded-xl flex items-center justify-center shadow-md">
              <span className="text-white font-bold text-xl">N</span>
            </div>
            <div className="flex-1 ml-4">
              <h1 className="text-2xl font-bold text-gray-900">Welcome back, {user?.name}</h1>
              <p className="text-gray-600">Room {user?.roomNumber} • Nobu Hotel Marrakech</p>
            </div>
            <Link to="/dashboard/beauty-store">
              <Button variant="primary" className="flex items-center gap-2 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700">
                <Sparkles size={20} />
                Discover our Beauty Store
              </Button>
            </Link>
          </div>
        </div>

        {/* Promotional Slider */}
        <div className="mb-8">
          <Slider slides={sliderData} autoPlay={true} interval={6000} />
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="text-center">
              <div className={`text-2xl font-bold text-${stat.color}-600 mb-1`}>
                {stat.value}
              </div>
              <div className="text-sm text-gray-600">{stat.label}</div>
              <div className={`h-1 bg-${stat.color}-500 rounded-full mt-2`}></div>
            </Card>
          ))}
        </div>

        {/* Services Grid (navigation rapide) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {navigationServices.map((service) => {
            const Icon = service.icon;
            return (
              <Link
                key={service.title}
                to={service.to}
                className="group"
              >
                <Card className="text-center hover:shadow-xl transition-all duration-300 group-hover:-translate-y-2 group-hover:shadow-orange-100">
                  <div className={`w-16 h-16 bg-${service.color}-100 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:bg-${service.color}-200 transition-colors`}>
                    <Icon className={`text-${service.color}-600`} size={32} />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-1">{service.title}</h3>
                  <p className="text-sm text-gray-600">{service.description}</p>
                </Card>
              </Link>
            );
          })}
        </div>

        {/* Quick Actions */}
        <Card className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500"></div>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Restaurant Preview */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                    <Utensils className="text-orange-600" size={20} />
                    Restaurant Nobu - Sélection
                  </h3>
                  <Link to="/dashboard/restaurant" className="text-orange-600 text-sm hover:underline">
                    Voir le menu complet →
                  </Link>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {menuItems.map((item) => (
                    <Link key={item.id} to="/dashboard/restaurant" className="block">
                      <div className="bg-gradient-to-br from-orange-50 to-amber-50 rounded-xl p-4 hover:from-orange-100 hover:to-amber-100 transition-all duration-300 border border-orange-200 hover:border-orange-300">
                        <img src={item.image} alt={item.name} className="w-full h-24 object-cover rounded-lg mb-3 shadow-sm" />
                        <h4 className="font-semibold text-gray-900 text-sm mb-1">{item.name}</h4>
                        <p className="text-xs text-gray-600 mb-2 line-clamp-2">{item.description}</p>
                        <div className="flex items-center justify-between">
                          <p className="text-orange-600 font-bold">{item.price} $</p>
                          <span className="text-xs bg-orange-200 text-orange-800 px-2 py-1 rounded-full">
                            {item.category === 'appetizers' ? 'Appetizer' :
                             item.category === 'mains' ? 'Main' :
                             item.category === 'desserts' ? 'Dessert' :
                             item.category === 'beverages' ? 'Beverage' : item.category}
                          </span>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>

              {/* Services Preview */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                    <Bell className="text-green-600" size={20} />
                    Available Services
                  </h3>
                  <Link to="/dashboard/services" className="text-green-600 text-sm hover:underline">
                    View All →
                  </Link>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {services.map((service) => (
                    <div key={service.id} className="bg-green-50 rounded-lg p-4 hover:bg-green-100 transition-colors">
                      <img src={service.imageUrl} alt={service.name} className="w-full h-24 object-cover rounded-lg mb-2" />
                      <h4 className="font-medium text-gray-900 text-sm">{service.name}</h4>
                      <p className="text-green-600 font-semibold">
                        {service.price > 0 ? `${service.price} $` : 'Complimentary'}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Activities Preview */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                    <Calendar className="text-purple-600" size={20} />
                    Featured Activities
                  </h3>
                  <Link to="/dashboard/activities" className="text-purple-600 text-sm hover:underline">
                    View All →
                  </Link>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {activities.map((activity) => (
                    <div key={activity.id} className="bg-purple-50 rounded-lg p-4 hover:bg-purple-100 transition-colors">
                      <img src={activity.imageUrl} alt={activity.name} className="w-full h-24 object-cover rounded-lg mb-2" />
                      <h4 className="font-medium text-gray-900 text-sm">{activity.name}</h4>
                      <div className="flex items-center justify-between">
                        <p className="text-purple-600 font-semibold">{activity.price} $</p>
                        <div className="flex items-center gap-1">
                          <Star className="text-yellow-500 fill-current" size={12} />
                          <span className="text-xs text-gray-600">{activity.rating}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </Card>

        {/* Special Offers */}
        <Card className="mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="text-orange-500" size={20} />
            <h2 className="text-lg font-semibold text-gray-900">Special Offers</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-orange-50 to-yellow-50 rounded-lg border border-orange-100">
              <Gift className="text-orange-600" size={24} />
              <div>
                <div className="font-medium text-gray-900">Welcome Drink</div>
                <div className="text-sm text-gray-600">Complimentary cocktail at the bar</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border border-purple-100">
              <Star className="text-purple-600" size={24} />
              <div>
                <div className="font-medium text-gray-900">Late Check-out</div>
                <div className="text-sm text-gray-600">Until 2:00 PM complimentary</div>
              </div>
            </div>
          </div>
        </Card>

        {/* Hotel Info */}
        <Card>
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Hotel Information</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
            <div>
              <h3 className="font-medium text-gray-900 mb-2">Check-out Time</h3>
              <p className="text-gray-600 flex items-center gap-2">
                <Clock size={16} /> 12:00 PM
              </p>
            </div>
            <div>
              <h3 className="font-medium text-gray-900 mb-2">Concierge</h3>
              <p className="text-gray-600 flex items-center gap-2">
                <MessageCircle size={16} /> Available 24/7
              </p>
            </div>
            <div>
              <h3 className="font-medium text-gray-900 mb-2">Room Service</h3>
              <p className="text-gray-600 flex items-center gap-2">
                <Package size={16} /> Until 11:00 PM
              </p>
            </div>
            <div>
              <h3 className="font-medium text-gray-900 mb-2">WiFi</h3>
              <p className="text-gray-600 flex items-center gap-2">
                <Wifi size={16} /> NobuGuest_Free
              </p>
            </div>
          </div>
        </Card>
      </div>
      <Navigation />
    </div>
  );
};

export default Dashboard;