import React, { useState } from 'react';
import { MapPin, Navigation as NavigationIcon, Phone, Clock, Wifi, Car } from 'lucide-react';
import Card from '../../components/UI/Card';
import BackButton from '../../components/UI/BackButton';
import Navigation from '../../components/Layout/Navigation';

interface MapLocation {
  id: string;
  name: string;
  description: string;
  floor: string;
  icon: React.ReactNode;
  coordinates: { x: number; y: number };
}

const HotelMap: React.FC = () => {
  const [selectedLocation, setSelectedLocation] = useState<MapLocation | null>(null);

  const locations: MapLocation[] = [
    {
      id: 'reception',
      name: 'Réception',
      description: 'Accueil et services clients 24h/24',
      floor: 'Rez-de-chaussée',
      icon: <Phone className="text-blue-600" size={20} />,
      coordinates: { x: 50, y: 80 }
    },
    {
      id: 'restaurant',
      name: 'Restaurant Nobu',
      description: 'Cuisine japonaise fusion',
      floor: 'Rez-de-chaussée',
      icon: <MapPin className="text-orange-600" size={20} />,
      coordinates: { x: 25, y: 60 }
    },
    {
      id: 'spa',
      name: 'Spa & Wellness',
      description: 'Soins et détente',
      floor: '3ème étage',
      icon: <MapPin className="text-green-600" size={20} />,
      coordinates: { x: 75, y: 40 }
    },
    {
      id: 'fitness',
      name: 'Centre de Fitness',
      description: 'Équipements modernes 24h/24',
      floor: '3ème étage',
      icon: <Clock className="text-purple-600" size={20} />,
      coordinates: { x: 80, y: 25 }
    },
    {
      id: 'pool',
      name: 'Piscine',
      description: 'Piscine extérieure avec vue',
      floor: 'Terrasse',
      icon: <MapPin className="text-blue-500" size={20} />,
      coordinates: { x: 30, y: 30 }
    },
    {
      id: 'parking',
      name: 'Parking',
      description: 'Parking privé sécurisé',
      floor: 'Sous-sol',
      icon: <Car className="text-gray-600" size={20} />,
      coordinates: { x: 60, y: 85 }
    }
  ];

  const hotelInfo = [
    { icon: <MapPin size={16} />, label: 'Adresse', value: 'Avenue Mohammed VI, Marrakech' },
    { icon: <Phone size={16} />, label: 'Téléphone', value: '+212 524 XXX XXX' },
    { icon: <Wifi size={16} />, label: 'WiFi', value: 'NobuGuest_Free' },
    { icon: <Clock size={16} />, label: 'Check-out', value: '12:00 PM' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-blue-50 pb-20 lg:pb-0">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <BackButton to="/dashboard" />
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Plan de l'Hôtel</h1>
              <p className="text-gray-600">Découvrez nos espaces et services</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Interactive Map */}
          <div className="lg:col-span-2">
            <Card className="p-0 overflow-hidden">
              <div className="relative bg-gradient-to-br from-orange-100 to-blue-100 h-96 md:h-[500px]">
                {/* Hotel Building Outline */}
                <svg
                  viewBox="0 0 100 100"
                  className="absolute inset-0 w-full h-full"
                  style={{ filter: 'drop-shadow(0 4px 6px rgba(0, 0, 0, 0.1))' }}
                >
                  {/* Building outline */}
                  <rect
                    x="10" y="20" width="80" height="60"
                    fill="white"
                    stroke="#e5e7eb"
                    strokeWidth="0.5"
                    rx="2"
                  />
                  {/* Rooms grid */}
                  {Array.from({ length: 6 }, (_, i) => (
                    <g key={i}>
                      <rect
                        x={15 + (i % 3) * 25}
                        y={25 + Math.floor(i / 3) * 25}
                        width="20"
                        height="20"
                        fill="#f9fafb"
                        stroke="#e5e7eb"
                        strokeWidth="0.3"
                        rx="1"
                      />
                    </g>
                  ))}
                </svg>

                {/* Location Markers */}
                {locations.map((location) => (
                  <button
                    key={location.id}
                    onClick={() => setSelectedLocation(location)}
                    className="absolute transform -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full shadow-lg border-2 border-orange-500 flex items-center justify-center hover:scale-110 transition-transform duration-200 z-10"
                    style={{
                      left: `${location.coordinates.x}%`,
                      top: `${location.coordinates.y}%`
                    }}
                  >
                    {location.icon}
                  </button>
                ))}

                {/* Legend */}
                <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg p-3">
                  <h3 className="font-semibold text-sm text-gray-900 mb-2">Légende</h3>
                  <div className="space-y-1 text-xs text-gray-600">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                      <span>Services</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                      <span>Loisirs</span>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Location Details & Info */}
          <div className="space-y-6">
            {/* Selected Location */}
            {selectedLocation && (
              <Card>
                <div className="flex items-start gap-3 mb-4">
                  {selectedLocation.icon}
                  <div>
                    <h3 className="font-semibold text-gray-900">{selectedLocation.name}</h3>
                    <p className="text-sm text-gray-600">{selectedLocation.floor}</p>
                  </div>
                </div>
                <p className="text-gray-700 text-sm">{selectedLocation.description}</p>
              </Card>
            )}

            {/* Hotel Information */}
            <Card>
              <h3 className="font-semibold text-gray-900 mb-4">Informations Pratiques</h3>
              <div className="space-y-3">
                {hotelInfo.map((info, index) => (
                  <div key={index} className="flex items-center gap-3 text-sm">
                    <div className="text-orange-600">{info.icon}</div>
                    <div>
                      <span className="text-gray-600">{info.label}:</span>
                      <span className="ml-2 font-medium text-gray-900">{info.value}</span>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Quick Actions */}
            <Card>
              <h3 className="font-semibold text-gray-900 mb-4">Actions Rapides</h3>
              <div className="space-y-2">
                <button className="w-full flex items-center gap-3 p-3 bg-orange-50 rounded-lg hover:bg-orange-100 transition-colors text-left">
                  <NavigationIcon className="text-orange-600" size={20} />
                  <div>
                    <div className="font-medium text-gray-900">Directions</div>
                    <div className="text-sm text-gray-600">Obtenir un itinéraire</div>
                  </div>
                </button>
                <button className="w-full flex items-center gap-3 p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors text-left">
                  <Phone className="text-blue-600" size={20} />
                  <div>
                    <div className="font-medium text-gray-900">Contacter</div>
                    <div className="text-sm text-gray-600">Appeler la réception</div>
                  </div>
                </button>
              </div>
            </Card>
          </div>
        </div>
      </div>

      <Navigation />
    </div>
  );
};

export default HotelMap;
