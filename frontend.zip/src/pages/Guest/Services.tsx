import React, { useState, useEffect } from 'react';
import { Send, Loader2 } from 'lucide-react';
import { ServiceItem } from '../../types';
import { apiService } from '../../services/api';
import Card from '../../components/UI/Card';
import Button from '../../components/UI/Button';
import Input from '../../components/UI/Input';
import BackButton from '../../components/UI/BackButton';
import Navigation from '../../components/Layout/Navigation';
import { useAuth } from '../../contexts/AuthContext';
import toast from 'react-hot-toast';

const Services: React.FC = () => {
  const [services, setServices] = useState<ServiceItem[]>([]);
  const [selectedService, setSelectedService] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [loading, setLoading] = useState(false);
  const [servicesLoading, setServicesLoading] = useState(true);

  const { user } = useAuth();

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    try {
      const data = await apiService.getServices();
      setServices(data);
    } catch (error) {
      console.error('Failed to load services:', error);
    } finally {
      setServicesLoading(false);
    }
  };

  const serviceTypes = [
    { id: 'housekeeping', name: 'Housekeeping', icon: '🧹' },
    { id: 'maintenance', name: 'Maintenance', icon: '🔧' },
    { id: 'concierge', name: 'Concierge', icon: '🛎️' },
    { id: 'laundry', name: 'Laundry', icon: '👕' },
    { id: 'room-service', name: 'Room Service', icon: '🍽️' },
    { id: 'spa', name: 'Spa Booking', icon: '💆‍♀️' },
    { id: 'transport', name: 'Transportation', icon: '🚗' },
    { id: 'other', name: 'Other', icon: '📝' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedService || !description.trim()) {
      toast.error('Please select a service and provide a description');
      return;
    }
    if (!user?.id) {
      toast.error('You must be logged in');
      return;
    }

    setLoading(true);

    try {
      // Appel réel à l'API (POST /api/service-requests)
      await apiService.createServiceRequest({
        guestId: user.id,
        type: selectedService,
        description,
        priority: priority.toUpperCase(), // 'LOW' | 'MEDIUM' | 'HIGH'
      });

      toast.success('Service request submitted successfully!');
      setSelectedService('');
      setDescription('');
      setPriority('medium');
    } catch (error: any) {
      toast.error('Failed to submit service request');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-blue-50 pb-20 lg:pb-0">
      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <BackButton to="/dashboard" />
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Services</h1>
            <p className="text-gray-600">How can we assist you today?</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Service Request Form */}
          <Card>
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Request Service</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Service Type Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Service Type
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {serviceTypes.map((service) => (
                    <button
                      key={service.id}
                      type="button"
                      onClick={() => setSelectedService(service.id)}
                      className={`p-4 rounded-lg border-2 text-left transition-all ${
                        selectedService === service.id
                          ? 'border-orange-500 bg-orange-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="text-2xl mb-2">{service.icon}</div>
                      <div className="font-medium text-gray-900">{service.name}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Please describe your request in detail..."
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all resize-none"
                  required
                />
              </div>

              {/* Priority */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Priority Level
                </label>
                <div className="flex gap-3">
                  {[
                    { value: 'low', label: 'Low', color: 'green' },
                    { value: 'medium', label: 'Medium', color: 'yellow' },
                    { value: 'high', label: 'High', color: 'red' },
                  ].map((level) => (
                    <button
                      key={level.value}
                      type="button"
                      onClick={() => setPriority(level.value as any)}
                      className={`flex-1 py-2 px-4 rounded-lg border-2 transition-all ${
                        priority === level.value
                          ? `border-${level.color}-500 bg-${level.color}-50 text-${level.color}-700`
                          : 'border-gray-200 text-gray-600 hover:border-gray-300'
                      }`}
                    >
                      {level.label}
                    </button>
                  ))}
                </div>
              </div>

              <Button
                type="submit"
                variant="primary"
                size="lg"
                loading={loading}
                className="w-full"
              >
                <Send size={20} className="mr-2" />
                Submit Request
              </Button>
            </form>
          </Card>

          {/* Quick Services */}
          <div className="space-y-6">
            <Card>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Services</h2>
              <div className="space-y-3">
                {[
                  { title: 'Extra Towels', time: '15 min', icon: '🏨' },
                  { title: 'Room Cleaning', time: '30 min', icon: '🧹' },
                  { title: 'Fresh Linens', time: '20 min', icon: '🛏️' },
                  { title: 'Amenities Refill', time: '10 min', icon: '🧴' },
                ].map((service, index) => (
                  <button
                    key={index}
                    className="w-full flex items-center gap-3 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors text-left"
                  >
                    <span className="text-2xl">{service.icon}</span>
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">{service.title}</div>
                      <div className="text-sm text-gray-500">~{service.time}</div>
                    </div>
                  </button>
                ))}
              </div>
            </Card>

            <Card>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Emergency Contact</h2>
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-4 bg-red-50 rounded-lg">
                  <span className="text-2xl">🚨</span>
                  <div>
                    <div className="font-medium text-red-900">Emergency Services</div>
                    <div className="text-sm text-red-700">Available 24/7</div>
                  </div>
                  <Button variant="danger" size="sm" className="ml-auto">
                    Call Now
                  </Button>
                </div>
                
                <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-lg">
                  <span className="text-2xl">📞</span>
                  <div>
                    <div className="font-medium text-blue-900">Front Desk</div>
                    <div className="text-sm text-blue-700">General assistance</div>
                  </div>
                  <Button variant="secondary" size="sm" className="ml-auto">
                    Call
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>

      <Navigation />
    </div>
  );
};

export default Services;