import React, { useState, useEffect } from 'react';
import { Plus, Minus, ShoppingCart, Star } from 'lucide-react';
import { useCart } from '../../contexts/CartContext';
import { MenuItem } from '../../types';
import Card from '../../components/UI/Card';
import Button from '../../components/UI/Button';
import BackButton from '../../components/UI/BackButton';
import Modal from '../../components/UI/Modal';
import Navigation from '../../components/Layout/Navigation';
import toast from 'react-hot-toast';
import { apiService } from '../../services/api';
import { useAuth } from '../../contexts/AuthContext'; // pour récupérer l'utilisateur connecté

const Restaurant: React.FC = () => {
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showCart, setShowCart] = useState(false);
  const [loading, setLoading] = useState(true);

  const { user } = useAuth();
  const { items, addItem, updateQuantity, getTotalPrice, getTotalItems, clearCart } = useCart();

  const categories = ['all', 'appetizers', 'mains', 'desserts', 'beverages'];

  // Function to get fallback image based on category
  const getFallbackImage = (category: string) => {
    const fallbackImages = {
      appetizers: 'https://images.unsplash.com/photo-1572695157366-5e585ab2b69f?w=500&h=300&fit=crop',
      mains: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=500&h=300&fit=crop',
      desserts: 'https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?w=500&h=300&fit=crop',
      beverages: 'https://images.unsplash.com/photo-1608270586620-248524c67de9?w=500&h=300&fit=crop'
    };
    return fallbackImages[category as keyof typeof fallbackImages] || fallbackImages.mains;
  };

  // Handle image error by setting fallback
  const handleImageError = (e: React.SyntheticEvent<HTMLImageElement>, category: string) => {
    e.currentTarget.src = getFallbackImage(category);
  };

  // Charger le menu depuis le backend
  useEffect(() => {
    const fetchMenu = async () => {
      setLoading(true);
      try {
        const data = await apiService.getMenu();
        setMenuItems(data);
      } catch (error) {
        toast.error('Failed to load menu');
      } finally {
        setLoading(false);
      }
    };
    fetchMenu();
  }, []);

  // Filtrer par catégorie
  const filteredItems =
    selectedCategory === 'all'
      ? menuItems
      : menuItems.filter(item => item.category === selectedCategory);

  // Envoyer la commande vers la base de données
  const handleOrder = async () => {
    if (items.length === 0) {
      toast.error('Your cart is empty');
      return;
    }
    if (!user?.id) {
      toast.error('User not authenticated');
      return;
    }

    try {
      // Préparer le payload selon OrderRequest DTO du backend
      const orderPayload = {
        guestId: user.id,
        items: items.map(item => ({
          menuItemId: Number(item.menuItem.id),
          quantity: item.quantity,
          price: item.menuItem.price,
        })),
        total: getTotalPrice(),
        notes: '', // tu peux ajouter un champ notes si tu veux
      };

      await apiService.createOrder(orderPayload);

      toast.success('Order placed successfully!');
      clearCart();
      setShowCart(false);
    } catch (error) {
      toast.error('Failed to place order');
    }
  };

  // Loading Spinner
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-blue-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-blue-50 pb-20 lg:pb-0">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <BackButton to="/dashboard" />
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Restaurant</h1>
              <p className="text-gray-600">Experience culinary excellence</p>
            </div>
          </div>
          <Button
            onClick={() => setShowCart(true)}
            variant="primary"
            className="relative"
          >
            <ShoppingCart size={20} />
            {getTotalItems() > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {getTotalItems()}
              </span>
            )}
          </Button>
        </div>

        {/* Categories */}
        <div className="flex gap-2 mb-8 overflow-x-auto">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-lg whitespace-nowrap transition-all ${
                selectedCategory === category
                  ? 'bg-orange-500 text-white'
                  : 'bg-white text-gray-600 hover:bg-orange-50'
              }`}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </button>
          ))}
        </div>

        {/* Menu Items */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <Card key={item.id} padding={false} className="overflow-hidden">
              <div className="relative">
                <img
                  src={item.image || getFallbackImage(item.category)}
                  alt={item.name}
                  className="w-full h-48 object-cover"
                  onError={(e) => handleImageError(e, item.category)}
                />
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg px-2 py-1 flex items-center gap-1">
                  <Star className="text-yellow-500 fill-current" size={14} />
                  <span className="text-sm font-medium">4.8</span>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="font-semibold text-lg text-gray-900 mb-2">{item.name}</h3>
                <p className="text-gray-600 text-sm mb-4">{item.description}</p>
                
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-orange-600">${item.price}</span>
                  <Button
                    onClick={() => addItem(item)}
                    size="sm"
                    className="flex items-center gap-2"
                  >
                    <Plus size={16} />
                    Add
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Cart Modal */}
        <Modal
          isOpen={showCart}
          onClose={() => setShowCart(false)}
          title="Your Order"
          maxWidth="max-w-lg"
        >
          {items.length === 0 ? (
            <div className="text-center py-8">
              <ShoppingCart className="mx-auto text-gray-400 mb-4" size={48} />
              <p className="text-gray-600">Your cart is empty</p>
            </div>
          ) : (
            <div>
              <div className="space-y-4 mb-6">
                {items.map((item) => (
                  <div key={item.id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                    <img
                      src={item.menuItem.image || getFallbackImage(item.menuItem.category)}
                      alt={item.menuItem.name}
                      className="w-16 h-16 rounded-lg object-cover"
                      onError={(e) => handleImageError(e, item.menuItem.category)}
                    />
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">{item.menuItem.name}</h4>
                      <p className="text-orange-600 font-semibold">${item.menuItem.price}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="w-8 h-8 rounded-full bg-white border border-gray-200 flex items-center justify-center hover:bg-gray-50"
                      >
                        <Minus size={16} />
                      </button>
                      <span className="w-8 text-center font-medium">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="w-8 h-8 rounded-full bg-white border border-gray-200 flex items-center justify-center hover:bg-gray-50"
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="border-t pt-4 mb-6">
                <div className="flex justify-between items-center text-xl font-bold">
                  <span>Total:</span>
                  <span className="text-orange-600">${getTotalPrice()}</span>
                </div>
              </div>

              <Button
                onClick={handleOrder}
                variant="primary"
                size="lg"
                className="w-full"
              >
                Place Order
              </Button>
            </div>
          )}
        </Modal>
      </div>

      <Navigation />
    </div>
  );
};

export default Restaurant;