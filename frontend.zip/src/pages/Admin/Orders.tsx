import React, { useState, useEffect } from 'react';
import { Search, Eye, Clock, CheckCircle, XCircle, Package, MapPin, Euro } from 'lucide-react';
import Card from '../../components/UI/Card';
import Button from '../../components/UI/Button';
import Input from '../../components/UI/Input';
import Modal from '../../components/UI/Modal';
import { apiService } from '../../services/api';

interface OrderStats {
  totalOrders: number;
  pendingOrders: number;
  completedOrders: number;
  totalRevenue: number;
}

interface OrderType {
  id: string;
  guest?: {
    id: number;
    name: string;
    roomNumber: string;
    phone: string;
  };
  items?: {
    menuItem?: {
      name: string;
      category: string;
    };
    quantity: number;
    price: number;
  }[];
  total: number;
  status: string;
  notes?: string;
  createdAt: string;
}

const AdminOrders: React.FC = () => {
  const [orders, setOrders] = useState<OrderType[]>([]);
  const [filteredOrders, setFilteredOrders] = useState<OrderType[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedOrder, setSelectedOrder] = useState<OrderType | null>(null);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<OrderStats>({
    totalOrders: 0,
    pendingOrders: 0,
    completedOrders: 0,
    totalRevenue: 0
  });

  useEffect(() => {
    loadOrders();
  }, []);

  useEffect(() => {
    filterOrders();
  }, [orders, searchTerm, statusFilter]);

  const loadOrders = async () => {
    try {
      console.log('📦 Loading orders data from MySQL database...');
      
      // Check authentication
      const token = localStorage.getItem('hotel_token');
      const user = localStorage.getItem('hotel_user');
      
      if (!token || !user) {
        console.error('🚫 No authentication found');
        window.location.href = '/login';
        return;
      }

      // Fetch real orders data from MySQL database
      const ordersData = await apiService.getAdminOrders();
      console.log('✅ Raw API Response - Orders:', ordersData);
      console.log('🔍 Orders data type:', typeof ordersData, 'Length:', ordersData?.length);
      console.log('🔍 First order:', ordersData?.[0]);

      // Calculate stats from real data
      const totalOrders = ordersData.length;
      const pendingOrders = ordersData.filter((order: any) => 
        order.status === 'PENDING' || order.status === 'CONFIRMED' || order.status === 'PREPARING'
      ).length;
      const completedOrders = ordersData.filter((order: any) => 
        order.status === 'DELIVERED'
      ).length;
      const totalRevenue = ordersData.reduce((sum: number, order: any) => 
        sum + (order.total || 0), 0
      );

      setStats({
        totalOrders,
        pendingOrders,
        completedOrders,
        totalRevenue
      });

      // Transform orders data to match component interface  
      const transformedOrders: OrderType[] = ordersData.map((order: any) => ({
        id: order.id.toString(),
        guest: order.guest,
        items: order.items?.map((item: any) => ({
          menuItem: item.menuItem,
          quantity: item.quantity,
          price: item.price || item.menuItem?.price || 0
        })) || [],
        total: order.total,
        status: order.status,
        notes: order.notes,
        createdAt: order.createdAt
      }));

      setOrders(transformedOrders);
    } catch (error: any) {
      console.error('❌ Failed to load orders from database:', error);
      if (error?.message?.includes('Authentication') || error?.message?.includes('401')) {
        window.location.href = '/login';
      } else {
        setOrders([]);
      }
    } finally {
      setLoading(false);
    }
  };

  const filterOrders = () => {
    let filtered = orders;

    if (searchTerm) {
      filtered = filtered.filter(order =>
        order.guest?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.guest?.roomNumber?.includes(searchTerm) ||
        order.id.toString().includes(searchTerm)
      );
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(order => order.status.toLowerCase() === statusFilter);
    }

    setFilteredOrders(filtered);
  };

  const handleViewOrder = (order: OrderType) => {
    setSelectedOrder(order);
    setShowOrderModal(true);
  };

  const handleStatusUpdate = async (orderId: string, newStatus: string) => {
    try {
      await apiService.updateOrderStatus(orderId, newStatus);
      setOrders(prev =>
        prev.map(order =>
          order.id === orderId ? { ...order, status: newStatus } : order
        )
      );
    } catch (error) {
      console.error('Failed to update order status:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'confirmed': return 'bg-blue-100 text-blue-800';
      case 'preparing': return 'bg-orange-100 text-orange-800';
      case 'delivered': return 'bg-green-100 text-green-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'pending': return <Clock size={16} />;
      case 'confirmed': return <CheckCircle size={16} />;
      case 'preparing': return <Package size={16} />;
      case 'delivered': return <CheckCircle size={16} />;
      case 'cancelled': return <XCircle size={16} />;
      default: return <Clock size={16} />;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gestion des Commandes</h1>
          <p className="text-gray-600">Suivi et gestion des commandes clients</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Commandes</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalOrders}</p>
            </div>
            <div className="p-3 bg-blue-100 rounded-full">
              <Package className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">En Attente</p>
              <p className="text-2xl font-bold text-orange-600">{stats.pendingOrders}</p>
            </div>
            <div className="p-3 bg-orange-100 rounded-full">
              <Clock className="h-6 w-6 text-orange-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Livrées</p>
              <p className="text-2xl font-bold text-green-600">{stats.completedOrders}</p>
            </div>
            <div className="p-3 bg-green-100 rounded-full">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Revenus Total</p>
              <p className="text-2xl font-bold text-purple-600">{stats.totalRevenue}€</p>
            </div>
            <div className="p-3 bg-purple-100 rounded-full">
              <Euro className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <Input
              icon={Search}
              placeholder="Rechercher par client, chambre ou numéro de commande..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="md:w-48">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
            >
              <option value="all">Tous les statuts</option>
              <option value="pending">En attente</option>
              <option value="confirmed">Confirmé</option>
              <option value="preparing">En préparation</option>
              <option value="delivered">Livré</option>
              <option value="cancelled">Annulé</option>
            </select>
          </div>
        </div>
      </Card>

      {/* Orders Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Commande</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Client</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Chambre</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Total</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Statut</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Date</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredOrders.map((order) => (
                <tr key={order.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4">
                    <div className="font-medium text-gray-900">#{order.id}</div>
                  </td>
                  <td className="py-3 px-4">
                    <div>
                      <div className="font-medium text-gray-900">{order.guest?.name || 'Client inconnu'}</div>
                      <div className="text-sm text-gray-500">{order.guest?.phone || 'N/A'}</div>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <MapPin size={16} className="text-gray-400" />
                      <span className="font-medium">{order.guest?.roomNumber || 'N/A'}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-bold text-lg">{order.total}€</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                      {getStatusIcon(order.status)}
                      {order.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="text-sm text-gray-900">
                      {new Date(order.createdAt).toLocaleDateString('fr-FR')}
                    </div>
                    <div className="text-xs text-gray-500">
                      {new Date(order.createdAt).toLocaleTimeString('fr-FR')}
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewOrder(order)}
                      >
                        <Eye size={16} />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredOrders.length === 0 && (
          <div className="text-center py-8">
            <Package className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900">Aucune commande</h3>
            <p className="mt-1 text-sm text-gray-500">
              {searchTerm || statusFilter !== 'all' 
                ? 'Aucune commande ne correspond à vos critères de recherche.'
                : 'Aucune commande trouvée dans la base de données.'
              }
            </p>
          </div>
        )}
      </Card>

      {/* Order Details Modal */}
      <Modal
        isOpen={showOrderModal}
        onClose={() => setShowOrderModal(false)}
        title={`Détails de la commande #${selectedOrder?.id}`}
      >
        {selectedOrder && (
          <div className="space-y-6">
            {/* Order Info */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700">Client</label>
                <p className="text-gray-900">{selectedOrder.guest?.name || 'Client inconnu'}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Chambre</label>
                <p className="text-gray-900">{selectedOrder.guest?.roomNumber || 'N/A'}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Téléphone</label>
                <p className="text-gray-900">{selectedOrder.guest?.phone || 'N/A'}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Statut</label>
                <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(selectedOrder.status)}`}>
                  {getStatusIcon(selectedOrder.status)}
                  {selectedOrder.status}
                </span>
              </div>
            </div>

            {/* Order Items */}
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">Articles commandés</label>
              <div className="space-y-2">
                {selectedOrder.items && selectedOrder.items.length > 0 ? (
                  selectedOrder.items.map((item, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <div>
                        <div className="font-medium">{item.menuItem?.name || 'Article'}</div>
                        <div className="text-sm text-gray-500">Quantité: {item.quantity}</div>
                      </div>
                      <div className="font-medium">{item.price}€</div>
                    </div>
                  ))
                ) : (
                  <p className="text-gray-500 text-sm">Détails des articles non disponibles</p>
                )}
              </div>
            </div>

            {/* Total */}
            <div className="border-t pt-4">
              <div className="flex justify-between items-center">
                <span className="text-lg font-medium">Total</span>
                <span className="text-xl font-bold text-orange-600">{selectedOrder.total}€</span>
              </div>
            </div>

            {/* Notes */}
            {selectedOrder.notes && (
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Notes</label>
                <p className="text-gray-900 bg-gray-50 p-3 rounded-lg">{selectedOrder.notes}</p>
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-2 pt-4 border-t">
              {selectedOrder.status?.toLowerCase() === 'pending' && (
                <Button 
                  variant="primary" 
                  onClick={() => handleStatusUpdate(selectedOrder.id.toString(), 'CONFIRMED')}
                >
                  Confirmer
                </Button>
              )}
              {selectedOrder.status?.toLowerCase() === 'confirmed' && (
                <Button 
                  variant="primary" 
                  onClick={() => handleStatusUpdate(selectedOrder.id.toString(), 'PREPARING')}
                >
                  Préparer
                </Button>
              )}
              {selectedOrder.status?.toLowerCase() === 'preparing' && (
                <Button 
                  variant="primary" 
                  onClick={() => handleStatusUpdate(selectedOrder.id.toString(), 'DELIVERED')}
                >
                  Marquer livré
                </Button>
              )}
              <Button 
                variant="secondary" 
                onClick={() => setShowOrderModal(false)}
              >
                Fermer
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default AdminOrders;