import { useState, useEffect } from 'react';
import { Settings, Plus, Edit2, Trash2, Eye, Search, Zap } from 'lucide-react';
import Card from '../../components/UI/Card';
import Button from '../../components/UI/Button';
import Input from '../../components/UI/Input';
import Modal from '../../components/UI/Modal';
import { ServiceItem } from '../../types';
import { apiService } from '../../services/api';
import toast from 'react-hot-toast';

interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  available: boolean;
  durationMinutes: number;
  maxCapacity: number;
}

const AdminServices: React.FC = () => {
  const [services, setServices] = useState<Service[]>([]);
  const [filteredServices, setFilteredServices] = useState<Service[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [showServiceModal, setShowServiceModal] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadServices();
  }, []);

  useEffect(() => {
    filterServices();
  }, [services, searchTerm, categoryFilter]);

  const loadServices = async () => {
    try {
      // Load services from database
      const data = await apiService.getServices();
      
      // Transform database response to match component interface
      const transformedServices: Service[] = data.map((service: any) => ({
        id: service.id.toString(),
        name: service.name,
        description: service.description,
        price: service.price,
        category: service.category,
        available: service.available,
        durationMinutes: service.durationMinutes || 60,
        maxCapacity: service.maxCapacity || 1
      }));
      
      setServices(transformedServices);
    } catch (error) {
      console.error('Failed to load services:', error);
      setServices([]);
    } finally {
      setLoading(false);
    }
  };

  const filterServices = () => {
    let filtered = services;

    if (searchTerm) {
      filtered = filtered.filter(service =>
        service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        service.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        service.category.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (categoryFilter !== 'all') {
      filtered = filtered.filter(service => service.category === categoryFilter);
    }

    setFilteredServices(filtered);
  };

  const handleViewService = (service: Service) => {
    setSelectedService(service);
    setShowServiceModal(true);
  };

  const handleCreateService = () => {
    setSelectedService(null);
    setShowCreateModal(true);
  };

  const handleEditService = (service: Service) => {
    setSelectedService(service);
    setShowCreateModal(true);
  };

  const handleDeleteService = async (serviceId: string) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce service ?')) return;
    
    try {
      await apiService.deleteService(serviceId);
      setServices(prev => prev.filter(s => s.id !== serviceId));
      toast.success('Service supprimé avec succès');
    } catch (error) {
      toast.error('Erreur lors de la suppression');
    }
  };

  const handleToggleAvailability = async (service: Service) => {
    try {
      const updatedService = { ...service, available: !service.available };
      await apiService.updateService(service.id, updatedService);
      setServices(prev => prev.map(s => s.id === service.id ? updatedService : s));
      toast.success(`Service ${updatedService.available ? 'activé' : 'désactivé'}`);
    } catch (error) {
      toast.error('Erreur lors de la mise à jour');
    }
  };

  
  const categories = [...new Set(services.map(s => s.category))];
  const activeServices = services.filter(s => s.available).length;
  const totalRequests = services.reduce((sum, s) => sum, 0); // This would need to be calculated from service requests

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gestion des Services</h1>
          <p className="text-gray-600">Configuration et gestion des services hôteliers</p>
        </div>
        <Button variant="primary" onClick={handleCreateService}>
          <Plus size={20} className="mr-2" />
          Nouveau Service
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <Input
              icon={Search}
              placeholder="Rechercher par nom, description ou catégorie..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            >
              <option value="all">Toutes les catégories</option>
              {categories.map(category => (
                <option key={category} value={category}>{category}</option>
              ))}
            </select>
          </div>
        </div>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="text-center">
          <div className="text-2xl font-bold text-blue-600">{services.length}</div>
          <div className="text-sm text-gray-600">Total Services</div>
        </Card>
        <Card className="text-center">
          <div className="text-2xl font-bold text-green-600">{activeServices}</div>
          <div className="text-sm text-gray-600">Services Actifs</div>
        </Card>
        <Card className="text-center">
          <div className="text-2xl font-bold text-purple-600">{categories.length}</div>
          <div className="text-sm text-gray-600">Catégories</div>
        </Card>
        <Card className="text-center">
          <div className="text-2xl font-bold text-orange-600">{services.reduce((sum, s) => sum + s.price, 0)}€</div>
          <div className="text-sm text-gray-600">Prix Total</div>
        </Card>
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredServices.map((service) => (
          <Card key={service.id} className="relative">
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900 mb-1">{service.name}</h3>
                <p className="text-sm text-gray-600 mb-2">{service.description}</p>
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    service.available 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {service.available ? 'Disponible' : 'Indisponible'}
                  </span>
                  <span className="text-orange-600 font-semibold">{service.price}€</span>
                </div>
              </div>
            </div>

            <div className="space-y-2 text-xs text-gray-500 mb-4">
              <div>Catégorie: {service.category}</div>
              <div>Durée: {service.durationMinutes} min</div>
              <div>Capacité: {service.maxCapacity} personne(s)</div>
            </div>

            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={() => handleViewService(service)}>
                <Eye size={14} />
              </Button>
              <Button size="sm" variant="outline" onClick={() => handleEditService(service)}>
                <Edit2 size={14} />
              </Button>
              <Button 
                size="sm" 
                variant={service.available ? "danger" : "primary"}
                onClick={() => handleToggleAvailability(service)}
              >
                <Zap size={14} />
              </Button>
              <Button size="sm" variant="danger" onClick={() => handleDeleteService(service.id)}>
                <Trash2 size={14} />
              </Button>
            </div>
          </Card>
        ))}
      </div>

      {filteredServices.length === 0 && (
        <Card>
          <div className="text-center py-8 text-gray-500">
            <Settings size={48} className="mx-auto mb-2 opacity-50" />
            <p>Aucun service trouvé</p>
          </div>
        </Card>
      )}

      {/* Service Details Modal */}
      <Modal
        isOpen={showServiceModal}
        onClose={() => setShowServiceModal(false)}
        title="Détails du Service"
        maxWidth="max-w-2xl"
      >
        {selectedService && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nom du service</label>
                <p className="text-gray-900">{selectedService.name}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Prix</label>
                <p className="text-gray-900 font-semibold">{selectedService.price}€</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Catégorie</label>
                <p className="text-gray-900">{selectedService.category}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Statut</label>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  selectedService.available 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-red-100 text-red-800'
                }`}>
                  {selectedService.available ? 'Disponible' : 'Indisponible'}
                </span>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Durée</label>
                <p className="text-gray-900">{selectedService.durationMinutes} minutes</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Capacité maximale</label>
                <p className="text-gray-900">{selectedService.maxCapacity} personne(s)</p>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
              <p className="text-gray-900 bg-gray-50 p-3 rounded-lg">{selectedService.description}</p>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default AdminServices;