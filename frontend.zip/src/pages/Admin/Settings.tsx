import React, { useState, useEffect } from 'react';
import { Save, Hotel, MapPin, Phone, Mail, Clock, Wifi, Shield, Globe } from 'lucide-react';
import Card from '../../components/UI/Card';
import Button from '../../components/UI/Button';
import Input from '../../components/UI/Input';
import { HotelSettings } from '../../types/admin';
import toast from 'react-hot-toast';

const AdminSettings: React.FC = () => {
  const [settings, setSettings] = useState<HotelSettings>({
    id: '1',
    hotelName: 'Nobu Hotel Marrakech',
    address: 'Avenue Mohammed VI, Marrakech',
    phone: '+212 524 XXX XXX',
    email: 'contact@nobumarrakech.com',
    checkInTime: '15:00',
    checkOutTime: '12:00',
    currency: 'MAD',
    timezone: 'Africa/Casablanca',
    wifiPassword: 'NobuGuest_Free',
    emergencyNumber: '911',
    updatedAt: new Date().toISOString()
  });
  const [loading, setLoading] = useState(false);

  const handleInputChange = (field: keyof HotelSettings, value: string) => {
    setSettings(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success('Paramètres sauvegardés avec succès');
    } catch (error) {
      toast.error('Erreur lors de la sauvegarde');
    } finally {
      setLoading(false);
    }
  };

  const settingSections = [
    {
      title: 'Informations Générales',
      icon: <Hotel className="text-orange-600" size={20} />,
      fields: [
        { key: 'hotelName', label: 'Nom de l\'hôtel', icon: Hotel },
        { key: 'address', label: 'Adresse', icon: MapPin },
        { key: 'phone', label: 'Téléphone', icon: Phone },
        { key: 'email', label: 'Email', icon: Mail }
      ]
    },
    {
      title: 'Horaires & Politique',
      icon: <Clock className="text-blue-600" size={20} />,
      fields: [
        { key: 'checkInTime', label: 'Heure d\'arrivée', icon: Clock, type: 'time' },
        { key: 'checkOutTime', label: 'Heure de départ', icon: Clock, type: 'time' },
        { key: 'currency', label: 'Devise', icon: Globe },
        { key: 'timezone', label: 'Fuseau horaire', icon: Globe }
      ]
    },
    {
      title: 'Sécurité & Accès',
      icon: <Shield className="text-green-600" size={20} />,
      fields: [
        { key: 'wifiPassword', label: 'Réseau WiFi', icon: Wifi },
        { key: 'emergencyNumber', label: 'Numéro d\'urgence', icon: Phone }
      ]
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Paramètres de l'Hôtel</h1>
          <p className="text-gray-600">Configuration générale et préférences</p>
        </div>
        <Button
          variant="primary"
          loading={loading}
          onClick={handleSave}
        >
          <Save size={20} className="mr-2" />
          Sauvegarder
        </Button>
      </div>

      {/* Settings Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {settingSections.map((section, sectionIndex) => (
          <Card key={sectionIndex}>
            <div className="flex items-center gap-3 mb-6">
              {section.icon}
              <h3 className="text-lg font-semibold text-gray-900">{section.title}</h3>
            </div>
            
            <div className="space-y-4">
              {section.fields.map((field) => {
                const Icon = field.icon;
                return (
                  <Input
                    key={field.key}
                    label={field.label}
                    icon={Icon}
                    type={field.type || 'text'}
                    value={settings[field.key as keyof HotelSettings] as string}
                    onChange={(e) => handleInputChange(field.key as keyof HotelSettings, e.target.value)}
                  />
                );
              })}
            </div>
          </Card>
        ))}
      </div>

      {/* System Information */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Informations Système</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
          <div>
            <div className="font-medium text-gray-900 mb-1">Version</div>
            <div className="text-gray-600">v1.0.0</div>
          </div>
          <div>
            <div className="font-medium text-gray-900 mb-1">Dernière mise à jour</div>
            <div className="text-gray-600">
              {new Date(settings.updatedAt).toLocaleDateString('fr-FR')}
            </div>
          </div>
          <div>
            <div className="font-medium text-gray-900 mb-1">Statut</div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-green-600">Opérationnel</span>
            </div>
          </div>
        </div>
      </Card>

      {/* Quick Actions */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Actions Rapides</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Button variant="outline" className="justify-start">
            <Shield size={16} className="mr-2" />
            Sauvegarder Config
          </Button>
          <Button variant="outline" className="justify-start">
            <Globe size={16} className="mr-2" />
            Changer Langue
          </Button>
          <Button variant="outline" className="justify-start">
            <Clock size={16} className="mr-2" />
            Réinitialiser Cache
          </Button>
          <Button variant="outline" className="justify-start">
            <Mail size={16} className="mr-2" />
            Test Email
          </Button>
        </div>
      </Card>
    </div>
  );
};

export default AdminSettings;