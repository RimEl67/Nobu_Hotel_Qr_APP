import { MenuItem, ServiceItem, ActivityItem, Order, ServiceRequest, ActivityReservation } from '../types';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8080/api';

class ApiService {
  private token: string | null = null;

  setToken(token: string) {
    this.token = token;
    localStorage.setItem('hotel_token', token);
  }

  getToken(): string | null {
    if (!this.token) {
      this.token = localStorage.getItem('hotel_token');
    }
    return this.token;
  }

  clearToken() {
    this.token = null;
    localStorage.removeItem('hotel_token');
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${API_BASE_URL}${endpoint}`;
    const token = this.getToken();

    const config: RequestInit = {
      headers: {
        'Content-Type': 'application/json',
        ...(token && { 'Authorization': `Bearer ${token}` }),
        ...options.headers,
      },
      ...options,
    };

    try {
      const response = await fetch(url, config);

      // Si le backend renvoie une erreur
      if (!response.ok) {
        let message = `HTTP error! status: ${response.status}`;
        // Essaye de lire le body JSON ou texte
        try {
          const contentType = response.headers.get('content-type');
          if (contentType && contentType.includes('application/json')) {
            const data = await response.json();
            if (data && data.message) message = data.message;
            else if (typeof data === 'string') message = data;
            else if (data && data.error) message = data.error;
            throw new Error(message);
          } else {
            const text = await response.text();
            throw new Error(text || message);
          }
        } catch (e: any) {
          throw new Error(message);
        }
      }

      return await response.json();
    } catch (error) {
      // Log pour debug
      console.error('API request failed:', error);
      throw error;
    }
  }

  // --- Auth
  async authenticateGuest(name: string, roomNumber: string, phone: string) {
    return this.request<any>('/guests/authenticate', {
      method: 'POST',
      body: JSON.stringify({ name, roomNumber, phone }),
    });
  }

  async authenticateAdmin(username: string, password: string) {
    return this.request<any>('/admins/authenticate', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });
  }

  // --- Menu & Orders
  async getMenu(): Promise<MenuItem[]> {
    return this.request<MenuItem[]>('/menu');
  }

  async createOrder(orderData: any): Promise<Order> {
    return this.request<Order>('/orders', {
      method: 'POST',
      body: JSON.stringify(orderData),
    });
  }

  async getOrders(): Promise<Order[]> {
    return this.request<Order[]>('/orders');
  }

  async getGuestOrders(guestId: string): Promise<Order[]> {
    return this.request<Order[]>(`/orders/guest/${guestId}`);
  }


 // --- Services
  async getServices(): Promise<ServiceItem[]> {
    return this.request<ServiceItem[]>('/services');
  }

  async getServicesByCategory(category: string): Promise<ServiceItem[]> {
    return this.request<ServiceItem[]>(`/services/category/${category}`);
  }

  // --- Activities
  async getActivities(): Promise<ActivityItem[]> {
    return this.request<ActivityItem[]>('/activities');
  }

  async getActivitiesByCategory(category: string): Promise<ActivityItem[]> {
    return this.request<ActivityItem[]>(`/activities/category/${category}`);
  }

  // --- Service Requests
  async createServiceRequest(requestData: any): Promise<ServiceRequest> {
    return this.request<ServiceRequest>('/service-requests', {
      method: 'POST',
      body: JSON.stringify(requestData),
    });
  }

  async getServiceRequests(): Promise<ServiceRequest[]> {
    return this.request<ServiceRequest[]>('/service-requests');
  }

  async updateServiceRequestStatus(id: string, status: string) {
    return this.request(`/service-requests/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    });
  }

  // --- Activity Reservations
  async createReservation(reservationData: any): Promise<ActivityReservation> {
    try {
      console.log('API: Sending reservation request:', reservationData);
      const result = await this.request<ActivityReservation>('/reservations', {
        method: 'POST',
        body: JSON.stringify(reservationData),
      });
      console.log('API createReservation success:', result);
      return result;
    } catch (error: any) {
      console.error('API createReservation error:', error);
      console.error('Error details:', {
        message: error.message,
        stack: error.stack,
        name: error.name
      });
      throw error;
    }
  }

  async getReservations(): Promise<ActivityReservation[]> {
    return this.request<ActivityReservation[]>('/reservations');
  }

  async getReservationsByGuest(guestId: string): Promise<ActivityReservation[]> {
    return this.request<ActivityReservation[]>(`/reservations/guest/${guestId}`);
  }

  async updateReservationStatus(id: string, status: string): Promise<ActivityReservation> {
    return this.request<ActivityReservation>(`/reservations/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    });
  }

  async checkAvailability(activityType: string, date: string, time: string): Promise<any> {
    return this.request<any>(`/reservations/availability?activityType=${activityType}&date=${date}&time=${time}`);
  }

  // --- Beauty Products & Orders
  async getBeautyProducts(): Promise<any[]> {
    try {
      return await this.request<any[]>('/beauty-products');
    } catch (error) {
      console.error('Beauty products API error:', error);
      throw error;
    }
  }

  async getBeautyProductsByCategory(category: string): Promise<any[]> {
    return this.request<any[]>(`/beauty-products/category/${category}`);
  }

  async getBeautyProductById(id: string): Promise<any> {
    return this.request<any>(`/beauty-products/${id}`);
  }

  async createBeautyOrder(orderData: any): Promise<any> {
    return this.request<any>('/beauty-orders', {
      method: 'POST',
      body: JSON.stringify(orderData),
    });
  }

  async getBeautyOrders(): Promise<any[]> {
    return this.request<any[]>('/beauty-orders');
  }

  async getGuestBeautyOrders(guestId: string): Promise<any[]> {
    return this.request<any[]>(`/beauty-orders/guest/${guestId}`);
  }

  // --- Admin Stats
  async getAdminStats() {
    return this.request('/admin/stats');
  }

  async getStatsByPeriod(period: string) {
    return this.request(`/admin/stats?period=${period}`);
  }
  

  // --- Admin specific methods (NEW)
  async getGuests(): Promise<any[]> {
    return this.request<any[]>('/admin/guests');
  }

  async getGuestById(id: string): Promise<any> {
    return this.request<any>(`/admin/guests/${id}`);
  }

  async updateOrderStatus(id: string, status: string): Promise<Order> {
    return this.request<Order>(`/orders/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    });
  }

  async getAdminOrders(): Promise<Order[]> {
    return this.request<Order[]>('/admin/orders');
  }

  async getAdminServiceRequests(): Promise<ServiceRequest[]> {
    return this.request<ServiceRequest[]>('/admin/service-requests');
  }

  async getAdminReservations(): Promise<ActivityReservation[]> {
    return this.request<ActivityReservation[]>('/admin/reservations');
  }

  async createService(serviceData: any): Promise<ServiceItem> {
    return this.request<ServiceItem>('/admin/services', {
      method: 'POST',
      body: JSON.stringify(serviceData),
    });
  }

  async updateService(id: string, serviceData: any): Promise<ServiceItem> {
    return this.request<ServiceItem>(`/admin/services/${id}`, {
      method: 'PUT',
      body: JSON.stringify(serviceData),
    });
  }

  async deleteService(id: string): Promise<void> {
    return this.request<void>(`/admin/services/${id}`, {
      method: 'DELETE',
    });
  }
}

export const apiService = new ApiService();